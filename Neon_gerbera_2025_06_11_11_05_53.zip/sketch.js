function setup() {
  createCanvas(200, 200);// largura e altura da tela
  background(255); // representa a cor branca
}

function draw() { // desenho
  background(255); // representa a cor branca
 
  // Desenhar o centro da flor
  fill('##387AEB'); // Vermelho
  ellipse(100, 100, 50, 50); // Centro da flor (x,y, largura, altura)
 
  // Desenhar as pétalas
  fill('#CBFCD1'); // Verde
  ellipse(100, 50, 50, 80); // Pétala superior
  ellipse(100, 150, 50, 80); // Pétala inferior
  ellipse(50, 100, 80, 50); // Pétala esquerda
  ellipse(150, 100, 80, 50); // Pétala direita
 
  // Desenhar o caule
  line(100, 150, 100, 200); // Caule da flor (x,y,x,y)
  rect (10, 10, 10, 100); //Caule da flor (x, y, largura, altura)
}